package com.pet.numwan.numwan_pet;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class AdminPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_page);
    }
}
